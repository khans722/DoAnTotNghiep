import { v2 as cloudinary } from 'cloudinary'
import axios from 'axios';

// cloudinary.config({
//   cloud_name: 'khanhbatluc',
//   api_key: '139429812855649',
//   api_secret: 'ZbaVRrQYqmnqUo_eJO79RHQYWg8'
// })

const uploadFile = async (courseId, directory, fileName, file, fileType) => {
  // const key = `${courseId}/${directory}/${Date.now()}_${fileName}`
  // const params = {
  //   Bucket: bucketName,
  //   Key: key,
  //   Body: file,
  //   ContentType: fileType
  // }
  // const command = new PutObjectCommand(params)
  // await client.send(command)
  const formData = new FormData();
  
    formData.append("file", file);

    formData.append("upload_preset", "ncpanat5");
    formData.append("cloud_name", "khanhbatluc");

    const res = await fetch(
    "https://api.cloudinary.com/v1_1/khanhbatluc/upload",
    {
        method: "POST",
        body: formData,
    }
    );

    const data = await res.json();

    console.log(data);

  return data
}

// const deleteFile = async (fileURL) => {
//   const key = fileURL.split('.com/')[1]
//   const params = { Bucket: bucketName, Key: key }
//   const command = new DeleteObjectCommand(params)
//   await client.send(command)
// }

const cloudinaryService = { uploadFile }
export default cloudinaryService
