import styled from 'styled-components'

export const FlexSectionHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: baseline;
`
