export const STUDENT = 'student'
export const INSTRUCTOR = 'instructor'
export const ADMIN = 'admin'
