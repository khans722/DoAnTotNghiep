import React from 'react';
import { Typography, Tag } from 'antd';

const { Text } = Typography;

const SubmissionTimeTag = (props) => {
  const { status } = props || {}; // Ensure props is defined and provide a default empty object
  const { code, message } = status || {}; // Ensure status is defined and provide a default empty object

  return (
    <>
      {code === 'late' && <Tag color="red">{code}</Tag>}
      {code === 'onTime' && <Tag color="green">{code}</Tag>}
      <Text type="secondary">{message}</Text>
    </>
  );
};

export default SubmissionTimeTag;
