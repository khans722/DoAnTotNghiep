import React from 'react'

import { Button, Card, Dropdown, Menu } from 'antd'
import axios from 'axios'

const CourseImage = ({ image, backgroundColor }) => {
  if (!image)
    return (
      <div style={{ backgroundColor: `${backgroundColor}`, height: 256 }}></div>
    )

  return (
    <img
      style={{
        maxHeight: 256,
        objectFit: 'cover',
        objectPosition: 'top'
      }}
      alt="course img"
      src={image}
    />
  )
}

const CardContent = (props) => {
  const {
    description,
    enrolled,
    onEnroll,
    onUnenroll,
    loadingEnroll,
    disableEnroll,
    price,
    idCourse
  } = props

  const handlePaymentCourse = async(amount, idCourse) =>{
    const response = await axios.post(`/courses/payment-momo`,{
      amount: amount,
      idCourse: idCourse
    });

    if(response && response.data){
      window.open(response.data, "_blank");
      onEnroll()
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {description}
      <div
        onClick={(event) => {
          event.stopPropagation()
        }}
        style={{
          marginTop: '20px',
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <div style={{color: 'red', fontWeight: 500, fontSize: 18}}>{new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(Number(price ?? 0))}</div>
        {!disableEnroll && (
          <>
            {!enrolled && (
              // <Button loading={loadingEnroll} onClick={() => onEnroll()}>
              //   Enroll
              // </Button>
              <Button loading={loadingEnroll} onClick={() => handlePaymentCourse(price, idCourse)}>
                Enroll
              </Button>
            )}

            {enrolled && (
              <Button loading={loadingEnroll} onClick={() => onUnenroll()}>
                Unenroll
              </Button>
            )}
          </>
        )}
      </div>
    </div>
  )
}

const CourseCard = (props) => {
  const {
    course,
    onClick,
    handleEnroll,
    handleUnenroll,
    removeCourse,
    disableEnroll
  } = props
  const { enrolled, privilege } = course

  const loadingEnroll = course.loadingEnroll

  const optionMenu = (
    <Menu>
      {privilege === 'student' && <Menu.Item>Review course</Menu.Item>}
      {(privilege === 'instructor' || privilege === 'admin') && (
        <Menu.Item onClick={removeCourse} danger>
          Delete course
        </Menu.Item>
      )}
    </Menu>
  )

  return (
    <Card
      hoverable
      bordered={false}
      cover={
        <CourseImage
          image={course.image}
          backgroundColor={course.backgroundColor}
        />
      }
      onClick={onClick}
    >
      <Card.Meta
        title={
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            {course.name}
            <span
              onClick={(event) => {
                event.stopPropagation()
              }}
            >
              {enrolled && !disableEnroll && (
                <Dropdown.Button
                  placement="bottomCenter"
                  type="text"
                  overlay={optionMenu}
                ></Dropdown.Button>
              )}
            </span>
          </div>
        }
        description={
          <CardContent
            loadingEnroll={loadingEnroll}
            price={course.price}
            description={course.description}
            enrolled={enrolled}
            onEnroll={handleEnroll}
            onUnenroll={handleUnenroll}
            disableEnroll={disableEnroll}
            idCourse={course.id}
          />
        }
      />
    </Card>
  )
}

export default CourseCard
