const express = require('express');
const auth = require('../middleware/auth')
const { createArticle, timeline, deleteArticle,
    UserArticles, articleId, editArticle , getAllArticles} = require('../controller/articleController/articleController');

const { like,unlike } = require('../controller/articleController/likeController');
const { BookMark, unBookMarked ,Bookedby } = require('../controller/articleController/bookmarkedController');
const { createComment, getComment, updateComment, deleteComment } = require('../controller/articleController/commentController');
const {followUser, unfollow , followers , follows } = require('../controller/articleController/followController') ; 

const router = new express.Router();

router.post('/newArticle', createArticle);
router.get('/getAllArticles', getAllArticles);

router.get('/timeline'  , timeline) ; 
router.get('/myBookedMarks'  , Bookedby);


router.get('/:name/articles', UserArticles);
router.get('/:articleId', articleId);
router.patch('/editArticle/:articleId', editArticle);
router.delete('/deleteArticle/:articleId', deleteArticle);

router.get('/:articleId/like', like) ;
router.delete('/:articleId/unlike', unlike) ;

router.get('/:articleId/bookMarked', BookMark);
router.delete('/:articleId/unBookMarked', unBookMarked);

router.post('/:articleId/addcomment', createComment)
router.get('/:articleId/comments', getComment)
router.patch('/:articleId/edit/:commentId', updateComment)
router.delete('/:articleId/delete/:commentId', deleteComment)

router.get('/:articleId/followUser'  , followUser) ;
router.delete('/:articleId/unfollow'  , unfollow) ; 
router.get('/:username/followers' , followers) ; 
router.get('/:username/follows'  , follows) ; 


module.exports = router


