const dbconfig = {
    url : "mongodb://localhost:27017/" , 
    dbname : ''
}

module.exports = dbconfig ; 